#include "EixoDinamico.h"

#include <cmath>

EixoDinamico::EixoDinamico(double minimoPadrao, double maximoPadrao,
                           Serie* base, bool orientacaoHorizontal) :
                           Eixo(minimoPadrao, maximoPadrao),
                           base(base), orientacaoHorizontal(orientacaoHorizontal) {
  if (orientacaoHorizontal)
    Eixo::titulo = base->getNomeDoCanalX();
  else Eixo::titulo = base->getNomeDoCanalY();
}

EixoDinamico::~EixoDinamico() {
}


bool EixoDinamico::minimoMaximoIguais() {
  Ponto* maximo = base->getLimiteSuperior();
  Ponto* minimo = base->getLimiteInferior();

  bool igual;
  const double epsilon = 1e-5;
  if (orientacaoHorizontal) {
    igual = std::abs(minimo->getX() - maximo->getX()) <= epsilon;
  } else {
    igual = std::abs(minimo->getY() - maximo->getY()) <= epsilon;
  }
  delete maximo;
  delete minimo;

  return igual;
}


double EixoDinamico::getMinimo() {
  if (base->getQuantidade() < 2 || minimoMaximoIguais())
    return Eixo::getMinimo();

  Ponto* minimo = base->getLimiteInferior();
  double valor;
  if (orientacaoHorizontal) {
    valor = minimo->getX();
  } else {
    valor = minimo->getY();
  }
  delete minimo;
  return valor;
}

double EixoDinamico::getMaximo() {
  if (base->getQuantidade() < 2 || minimoMaximoIguais())
    return Eixo::getMaximo();

  Ponto* maximo = base->getLimiteSuperior();
  double valor;
  if (orientacaoHorizontal) {
    valor = maximo->getX();
  } else {
    valor = maximo->getY();
  }
  delete maximo;
  return valor;
}

