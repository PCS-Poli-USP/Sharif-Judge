#include <iostream>
#include <stdexcept>

#include "Serie.h"
#include "SerieTemporal.h"
#include "Tela.h"
#include "InterfaceSerial.h"
#include "Grafico.h"
#include "Eixo.h"
#include "EixoDinamico.h"

using namespace std;

#define COMM "\\\\.\\COM3"

Eixo* criaEixoEstatico() {
	cout << "Informe o titulo: ";
	string titulo;
	cin >> titulo;

	cout << "Valor minimo: ";
	double minimo;
	cin >> minimo;

	cout << "Valor maximo: ";
	double maximo;
	cin >> maximo;

	return new Eixo (titulo, minimo, maximo);
}

Eixo* criaEixoDinamico (Serie* s, bool horizontal) {
	cout << "Valor minimo padrao: ";
	double minimo;
	cin >> minimo;

	cout << "Valor maximo padrao: ";
	double maximo;
	cin >> maximo;

	return new EixoDinamico (minimo, maximo, s, horizontal);
}

int main() {
	try {
		InterfaceSerial* is = new InterfaceSerial (COMM);

		is->inicializar();

    string nome;
		cout << "Informe o nome da serie: ";
		cin >> nome;

		string* nomes = is->getNomeDosCanais();

		cout << "Escolha o canal X:" << endl;
		cout << "0) Tempo" << endl;

		for (int i = 0 ; i < is->getQuantidadeDeCanais(); i++) {
			cout << i + 1 << ") " << nomes[i] << endl;
		}

		int canalX;
		cin >> canalX;

		cout << "Escolha o canal Y:" << endl;

		for (int i = 0 ; i < is->getQuantidadeDeCanais(); i++) {
			cout << i + 1 << ") " << nomes[i] << endl;
		}

		int canalY;
		cin >> canalY;

		Serie* s;

		if (canalX == 0) {
			s = new SerieTemporal (nome, nomes[canalY - 1]);
		} else s = new Serie (nome, nomes[canalX - 1],
			                      nomes[canalY - 1]);

		int pontos;
		cout << "Obter quantos pontos? ";
		cin >> pontos;

		cout << "Obtendo os pontos" << endl;

		for (int i = 0; i < pontos; i++) {
			is->atualizar();
			if (SerieTemporal* t = dynamic_cast<SerieTemporal*> (s) ) {
				t->adicionar (is->getValor (s->getNomeDoCanalY() ) );
			} else {
				s->adicionar (is->getValor (s->getNomeDoCanalX() ),
				              is->getValor (s->getNomeDoCanalY() ) );
			}
		}

		cout << "Gerando o grafico" << endl;
		string resposta;
    Eixo* x;
    cout << "O eixo X e estatico ou dinamico (e/d): ";
    cin >> resposta;

    if (resposta == "e" || resposta == "E")
      x = criaEixoEstatico();
    else x = criaEixoDinamico (s, true);

    Eixo* y;
    cout << "O eixo Y e' estatico ou dinamico (e/d): ";
    cin >> resposta;

    if (resposta == "e" || resposta == "E")
      y = criaEixoEstatico();
    else y = criaEixoDinamico (s, false);

    Grafico* g = new Grafico (x, y, s);
    g->desenhar();

    delete g;
    delete x;
    delete y;

		delete s;
		delete is;
	} catch (runtime_error* re) {
		cout << re->what() << endl;
		delete re;
	} catch (logic_error* le) {
		cout << le->what() << endl;
		delete le;
	}

	return 0;
}
