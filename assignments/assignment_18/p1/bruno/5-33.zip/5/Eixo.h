#ifndef EIXO_H
#define EIXO_H

#include <string>

using namespace std;

class Eixo {
public:
  /**
   * Cria um Eixo informando o t�tulo, o m�nimo e o m�ximo.
   */
  Eixo(string titulo, double minimo, double maximo);
  virtual ~Eixo();
  virtual string getTitulo();
  virtual double getMinimo();
  virtual double getMaximo();
protected: // Uau... Isso e avancado!
  Eixo(double minimo, double maximo);
  string titulo;
private:
  double minimo, maximo;
};

#endif // EIXO_H
