#ifndef GRAFICO_H
#define GRAFICO_H

#include "Eixo.h"
#include "Serie.h"

class Grafico {
public:
  /**
   * Cria um Grafico informando os Eixos e a Serie.
   */
  Grafico(Eixo* x, Eixo* y, Serie* serie);
  virtual ~Grafico();

  Eixo* getEixoX();
  Eixo* getEixoY();
  Serie* getSerie();

  /**
   * Desenha o Grafico na Tela.
   */
  void desenhar();
private:
  Eixo* x;
  Eixo* y;
  Serie* serie;
};

#endif // GRAFICO_H
