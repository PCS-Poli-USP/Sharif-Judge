#ifndef EIXODINAMICO_H
#define EIXODINAMICO_H

#include "Serie.h"
#include "Eixo.h"

class EixoDinamico : public Eixo {
public:
  /**
   * Cria um EixoDinamico informando o minimo e o maximo padrao,
   * a Serie que sera usada como base e a orientacao (true se for
   * horizontal e false se for vertical).
   */
  EixoDinamico(double minimoPadrao, double maximoPadrao,
               Serie* base, bool orientacaoHorizontal);

  virtual double getMinimo();
  virtual double getMaximo();
  virtual ~EixoDinamico();
private:
  bool minimoMaximoIguais();
  Serie* base;
  bool orientacaoHorizontal;
};

#endif // EIXODINAMICO_H
