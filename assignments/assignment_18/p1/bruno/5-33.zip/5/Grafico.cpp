#include "Grafico.h"
#include "Tela.h"

Grafico::Grafico(Eixo* x, Eixo* y, Serie* serie) : x(x), y(y), serie(serie) {
}

Grafico::~Grafico() {
}

Eixo* Grafico::getEixoX() {
  return x;
}

Eixo* Grafico::getEixoY() {
  return y;
}

Serie* Grafico::getSerie() {
  return serie;
}

void Grafico::desenhar() {
  Tela* t = new Tela();
  t->setEixoX(x->getTitulo(), x->getMinimo(), x->getMaximo());
  t->setEixoY(y->getTitulo(), y->getMinimo(), y->getMaximo());

  for (int i = 0; i < serie->getQuantidade(); i++) {
      Ponto* atual = serie->getPosicao(i);
      t->plotar(serie->getNome(), atual->getX(), atual->getY());
  }
  t->mostrar();
  delete t;
}
