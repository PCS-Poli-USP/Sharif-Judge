#include "Eixo.h"

Eixo::Eixo(string titulo, double minimo, double maximo) : titulo(titulo), minimo(minimo), maximo(maximo) {
}

Eixo::Eixo(double minimo, double maximo) : Eixo("", minimo, maximo) {
}

string Eixo::getTitulo() {
  return titulo;
}

double Eixo::getMinimo() {
  return minimo;
}

double Eixo::getMaximo() {
  return maximo;
}

Eixo::~Eixo() {

}
