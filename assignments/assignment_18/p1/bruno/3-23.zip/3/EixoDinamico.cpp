#include "EixoDinamico.h"
#include "Serie.h"
#define e 0.00001
#include <cmath>
EixoDinamico::EixoDinamico(double minimoPadrao, double maximoPadrao,Serie*base, bool orientacaoHorizontal)
    : Eixo (orientacaoHorizontal ? base->getNomeDoCanalX() : base->getNomeDoCanalY(), minimoPadrao, maximoPadrao)
{
    int maximo;
    int minimo;
    bool passou = false;
    this -> orientacaoHorizontal = orientacaoHorizontal;
     if (base-> getQuantidade()<= 2){
        this -> maximoPadrao = maximoPadrao;
        this -> minimoPadrao = minimoPadrao;
        passou = true;
    }
    if (passou == false){
        if (orientacaoHorizontal){
            maximo = base -> getLimiteSuperior()->getX();
            minimo = base -> getLimiteInferior()-> getX();
        }
        else{
            maximo = base -> getLimiteSuperior()->getY();
            minimo = base -> getLimiteInferior()-> getY();
        }
        this -> maximoPadrao = maximo;
        this -> minimoPadrao = minimo;
        if (abs(maximo-minimo)< e){
            this -> maximoPadrao = maximoPadrao;
            this -> minimoPadrao = minimoPadrao;
        }
    }
}

EixoDinamico::~EixoDinamico(){

}
