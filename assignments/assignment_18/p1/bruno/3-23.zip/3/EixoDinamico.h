#ifndef EIXODINAMICO_H
#define EIXODINAMICO_H
#include "Serie.h"
#include "Eixo.h"

class EixoDinamico : public Eixo
{
    public:
        EixoDinamico(double minimoPadrao, double maximoPadrao, Serie*base, bool orientacaoHorizontal);
        virtual ~EixoDinamico();
        double minimoPadrao;
        double maximoPadrao;
        bool orientacaoHorizontal;

    protected:

    private:
};

#endif // EIXODINAMICO_H
