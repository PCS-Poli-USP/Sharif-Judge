#ifndef PONTO_H
#define PONTO_H
#include <iostream>

using namespace std;

class Ponto
{
    private:

protected:
    double coordenadaX;
    double coordenadaY;
public:
    Ponto(double x, double y);

    virtual ~Ponto();

    double getX();

    double getY();

    void imprimir();

    bool eIgual(Ponto* outro);
};

#endif // PONTO_H
