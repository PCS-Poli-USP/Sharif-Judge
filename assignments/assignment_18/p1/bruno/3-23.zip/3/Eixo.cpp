#include "Eixo.h"
#include <iostream>
using namespace std;
Eixo::Eixo(string titulo, double minimo, double maximo){
    this->titulo=titulo;
    this->maximo=maximo;
    this->minimo=minimo;
}

Eixo::~Eixo(){

}

string Eixo::getTitulo(){
    return titulo;
}

double Eixo::getMinimo(){
    return minimo;
}

double Eixo::getMaximo(){
    return maximo;
}
