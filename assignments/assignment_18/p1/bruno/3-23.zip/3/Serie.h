#ifndef SERIE_H
#define SERIE_H
#include <iostream>
#include "Ponto.h"
#include <string>
#define NUMERO_MAXIMO_VALORES 10
using namespace std;


class Serie
{
    private:
    public:

        Serie(string nome, string nomeDoCanalX, string nomeDoCanalY);
        virtual ~Serie();
        Ponto* vetorDePontos[NUMERO_MAXIMO_VALORES];
        virtual int getQuantidade();
        virtual bool estaVazia();
        virtual void adicionar(double x, double y);
        virtual Ponto* getLimiteSuperior();
        virtual Ponto* getLimiteInferior();
        virtual Ponto* getPosicao(int posicao);
        virtual void imprimir();
        string getNome();
        string getNomeDoCanalX();
        string getNomeDoCanalY();
    protected:
        // Permite obter o nome, o nomeDoCanalX e o nomeDoCanalY.

         string nomeX;
        string nomeY;
        string nomeSerie;
        int qntd = 0; // quantidade de elementos da serie
};

#endif // SERIE_H
