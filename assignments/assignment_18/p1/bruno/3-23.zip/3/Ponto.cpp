#include "Ponto.h"
#define e 0.00001
#include <cmath>

// SE PRECISAR USAR COUT using namespace std;

using namespace std;

Ponto::Ponto(double x, double y){
    this->coordenadaX = x;
    this->coordenadaY = y;
}

Ponto::~Ponto(){

}

double Ponto::getX(){
    //se o conteudo da posi��o indicada for nulo ele fica doidao e para de rodar
    return coordenadaX;
}

double Ponto::getY(){
    //se o conteudo da posi��o indicada no vetor for nulo ele fica maluco
    return coordenadaY;
}



void Ponto::imprimir(){
    cout<< "( " << getX() << " , " << getY() << " )" << endl;
}

bool Ponto::eIgual(Ponto* outro){
    // ver se o X e o Y sao iguais.
    double Xoutro = outro->getX();
    double Youtro = outro->getY();
    double Xesse = this->getX();
    double Yesse = this->getY();
    if (abs(Xoutro-Xesse)<e && abs(Youtro-Yesse)<e)return true;
    else{
        return false;
    }
}
