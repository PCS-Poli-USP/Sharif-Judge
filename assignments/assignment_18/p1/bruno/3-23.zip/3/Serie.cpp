#include "Serie.h"
#include<stdio.h>
#include <iostream>
#include <cstddef>

using namespace std;

Serie::Serie(string nomeSerie, string nomeDoCanalX, string nomeDoCanalY){
    this-> nomeSerie = nomeSerie;
    this-> nomeX = nomeDoCanalX;
    this-> nomeY = nomeDoCanalY;
}

Serie::~Serie(){

}


string Serie::getNome(){
    return nomeSerie;
}

string Serie::getNomeDoCanalX(){
    return nomeX;
}

string Serie::getNomeDoCanalY(){
    return nomeY;
}

int Serie::getQuantidade(){
    return qntd;
}

bool Serie::estaVazia(){
    if (getQuantidade()==0){
        return true;
    }else {
        return false;
    }
}

void Serie::adicionar(double x, double y){ // add popnto numa serie ja ex   ente
    int aux1;
    aux1=getQuantidade();
    Ponto *a = new Ponto(x,y);
    if(aux1 < NUMERO_MAXIMO_VALORES){
        vetorDePontos[aux1] = a;
        Ponto *a = new Ponto(x,y);
        qntd ++;
    }
}

Ponto* Serie::getLimiteSuperior(){
    //Ponto *p = new Ponto(); // para criar um ponto preciso passar seus
    // argumentos X e Y como a ideia original era pegar
    /*    aux1 = vetorDePontos[0]->coordenadaX;
          aux2 = vetorDePontos[0]->coordenadaY;
          p -> setX(aux1);
          p-> setY (aux2);

          */
    int tamanhodovetor = getQuantidade();
    int i = 0;
    double aux1, aux2;
    if (tamanhodovetor == 0){
        return NULL;
    }else {
          aux1 = vetorDePontos[0]->getX();
          aux2 = vetorDePontos[0]->getY();
          Ponto *p = new Ponto(aux1,aux2);
        for (i=1;i < tamanhodovetor; i++){
            if (vetorDePontos[i]->getX() > p->getX()){
                aux1 = vetorDePontos[i]->getX();
            }
            if (vetorDePontos[i]->getY() > p->getY()){
                aux2 = vetorDePontos[i]->getY();
            }
            Ponto *p = new Ponto(aux1,aux2);
        }
        return p;
        }
}

Ponto* Serie::getLimiteInferior(){
    int tamanhodovetor = this -> getQuantidade();
    int i = 0;
    double aux1, aux2;
    if (tamanhodovetor == 0){
        return NULL;
    }else {
          aux1 = vetorDePontos[0]->getX();
          aux2 = vetorDePontos[0]->getY();
          Ponto *p = new Ponto(aux1,aux2);
        for (i=1;i < tamanhodovetor; i++){
            if (vetorDePontos[i]->getX() < p->getX()){
                aux1 = vetorDePontos[i]->getX();
            }
            if (vetorDePontos[i]-> getY()< p->getY()){
                aux2 = vetorDePontos[i]->getY();
            }
            Ponto *p = new Ponto(aux1,aux2);
        }
        return p;
        }
}

Ponto* Serie::getPosicao(int posicao){ // obtem as coordenadas X e Y na posi��o especificada.
    double x,y;
    if (getQuantidade() == 0) return NULL;
    if(posicao >=0 && posicao <NUMERO_MAXIMO_VALORES){
        // COLOQUEI NUMERO MAXIMO VALORES E NAO QUANTIDADE
        x = vetorDePontos[posicao]->getX();
        y = vetorDePontos[posicao]->getY();
        Ponto*p = new Ponto(x,y);
        return p;
    }else {
        return NULL;
    }
}

void Serie::imprimir(){
    int aux2 = getQuantidade();
    int j = 0;
    //double xaux;
    //double yaux;
    if (aux2 == 0){
        cout<< "Serie "<< nomeSerie<<endl;
        cout<< "EMPTY"<< endl;
    }else{
        cout<< "Serie "<< nomeSerie<<endl;
        while (j<aux2){
            vetorDePontos[j] -> imprimir();
            //xaux = vetordepontos[j]->coordenadaX;
            //yaux = vetordepontos[j]->coordenadaY;
            //cout<< "(" << xaux <<", " <<yaux << ")"<<endl;
            j = j +1;
    }
    }
}

