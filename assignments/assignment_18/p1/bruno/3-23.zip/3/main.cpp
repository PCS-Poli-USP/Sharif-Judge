#include <iostream>

#include "Serie.h"
#include "Ponto.h"
#include "InterfaceSerial.h"
#include "Tela.h"
#include "Eixo.h"
#include "EixoDinamico.h"
#include "Grafico.h"
#include "SerieTemporal.h"
#define COMM  "\\\\.\\COM3"
using namespace std;

int main()
{
    InterfaceSerial*inter1 = new InterfaceSerial(COMM);
    inter1-> inicializar();
    string canalX;
    string canalY;
    string nomeSerie;
    int i, quantidadeDePontos;
    double valorX, valorY, valorMax, valorMin;
    string situacao;
    string titulo;
    Eixo*eixoX;
    Eixo* eixoY;
    Grafico* g;
    cout<< "Informe o nome da serie: "<< endl;
    cin >> nomeSerie;
    cout<<"Escolha o canal X:"<< endl;
    cout<<"0) Tempo"<< endl;
    for (i=0; i <= inter1 -> getQuantidadeDeCanais(); i++){
        cout<< i+1<< ") "<< inter1 -> getNomeDosCanais()[i] <<endl;
    }
    cin >> i;
    if(i==0) canalX = "Tempo";
    else{
        canalX = inter1 -> getNomeDosCanais()[i-1];
    }
    cout<<"Escolha o nome do canal Y"<< endl;
    for (i=0; i <= inter1 -> getQuantidadeDeCanais(); i++){
        cout<< i+1<< ") "<< inter1 -> getNomeDosCanais()[i] <<endl;
    }
    cin >> i;
    canalY = inter1 -> getNomeDosCanais()[i-1];
    Serie*s = new Serie(nomeSerie, canalX, canalY);
    SerieTemporal*st = new SerieTemporal(nomeSerie,canalY);
    cout<< "Obter quantos pontos?"<< endl;
    cin >> quantidadeDePontos;
    cout << "Obtendo os pontos"<<endl;
    for (i = 0; i < quantidadeDePontos; i++) {
        if (canalX != "Tempo"){
            inter1-> atualizar();
            valorX = inter1-> getValor (canalX);
            valorY = inter1 -> getValor (canalY);
            s -> adicionar (valorX, valorY);
        }
        if (canalX == "Tempo"){
            inter1-> atualizar();
            valorY = inter1 -> getValor (canalY);
            st -> adicionar (valorY);
        }
    }
    cout << "Gerando o gr�fico" << endl;

    cout << "O eixo X e estatico ou dinamico(e/d): " << endl;
    cin >> situacao;

    if (situacao == "e"){
        if (canalX != "Tempo"){
            cout<< "Informe o titulo: "<< endl;
            cin >> titulo;
        }
        if (canalX == "Tempo") titulo = "Tempo";
        cout<< "Valor minimo: "<< endl;
        cin >> valorMin;
        cout<< "Valor maximo: "<< endl;
        cin >> valorMax;
        Eixo* eixoX = new Eixo(titulo,valorMin, valorMax);
    }
    if (situacao == "d"){
        cout<< "Valor minimo padrao: "<< endl;
        cin >> valorMin;
        cout<< "Valor maximo padrao: "<< endl;
        cin >> valorMax;
        if (canalX == "Tempo"){
                EixoDinamico* eixoX = new EixoDinamico(valorMin, valorMax, st, true);
        }
        else{
            EixoDinamico*eixoX = new EixoDinamico(valorMin, valorMax, s, true);
        }
    }
     cout << "O eixo Y e estatico ou dinamico(e/d): " << endl;
    cin >> situacao;

    if (situacao == "e"){
        cout<< "Informe o titulo: "<< endl;
        cin >> titulo;
        cout<< "Valor minimo: "<< endl;
        cin >> valorMin;
        cout<< "Valor maximo: "<< endl;
        cin >> valorMax;
        Eixo* eixoY = new Eixo(titulo,valorMin, valorMax);
    }
    if (situacao == "d"){
        cout<< "Valor minimo padrao: "<< endl;
        cin >> valorMin;
        cout<< "Valor maximo padrao: "<< endl;
        cin >> valorMax;
        if (canalX == "Tempo") EixoDinamico*eixoY = new EixoDinamico(valorMin, valorMax, st, true);
        else{
            EixoDinamico*eixoX = new EixoDinamico(valorMin, valorMax, s, true);
        }
    }
    if (canalX == "Tempo") Grafico*g = new Grafico(eixoX, eixoY, st);
    else{
        Grafico*g = new Grafico(eixoX, eixoY, s);

    }
    g -> desenhar();
    delete g;
    delete eixoX;
    delete eixoY;
    delete st;
    delete s;
    delete inter1;
    return 0;




}


