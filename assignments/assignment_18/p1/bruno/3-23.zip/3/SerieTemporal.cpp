#include "SerieTemporal.h"
#include "Serie.h"
#define e 0.00001
#include <cmath>

SerieTemporal::SerieTemporal (string nome, string NomeDoCanalY):Serie(nome,"Tempo", NomeDoCanalY){
}

SerieTemporal::~SerieTemporal(){
}

void SerieTemporal::adicionar (double valor){
    int i = tempo;
    SerieTemporal::adicionar(i, valor);
    tempo ++;
}

void SerieTemporal::adicionar (double x,double y){
    int i;
    bool passou = false;
    Ponto*p = new Ponto(x,y);
    for(i = 0;i < getQuantidade();i++ ){
        if(abs(p->getX()-vetorDePontos[i]->getX())< e){
                vetorDePontos[i] = p;
                passou = true;
        }
    }
    if(!passou) Serie::adicionar(x,y);
}
