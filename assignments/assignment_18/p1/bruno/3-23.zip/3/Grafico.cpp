#include "Grafico.h"
#include "Eixo.h"
#include "Serie.h"
#include "Tela.h"
//#include "Tela.h"
//testar TODAS as possibilidades
Grafico::Grafico(Eixo *x, Eixo *y, Serie *serie){
    this-> x = x;
    this -> y = y;
    this -> serie = serie;
}

Grafico::~Grafico(){
}

Eixo* Grafico::getEixoX(){
    return x;
}

Eixo* Grafico::getEixoY(){
    return y;
}

Serie* Grafico::getSerie(){
    return serie;
}

void Grafico::desenhar(){
    int i;
    Tela*t= new Tela;
    t-> setEixoX(x->getTitulo(), x-> getMinimo(), x-> getMaximo());
    t-> setEixoY(y->getTitulo(), y-> getMinimo(), y-> getMaximo());
    for(i=0; i < serie->getQuantidade();i++){
        t -> plotar(serie->getNome(), serie-> getPosicao(i)-> getX(), serie-> getPosicao(i)-> getY());
    }
    t-> mostrar();
    delete t;
}
