#include "Ponto.h"
using namespace std;
#include<iostream>

Ponto::Ponto(double x, double y){
    Xponto = x;
    Yponto = y;
}

Ponto::~Ponto(){

}

double Ponto::getX(){
    return Xponto;
}

double Ponto::getY(){
    return Yponto;
}

void Ponto::imprimir(){
    cout << "(" << Xponto << ", " << Yponto << ")" << endl;
}

bool Ponto::eIgual(Ponto *p){
    if ( (Xponto - p->getX() <= Erro && Xponto - p->getX() > - Erro ) && (Yponto - p->getY() <= Erro && Yponto - p->getY() > - Erro  )){
        return true;
    }
    else
        return false;
}

