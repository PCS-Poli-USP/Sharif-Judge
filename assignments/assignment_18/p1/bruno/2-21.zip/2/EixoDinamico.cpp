#include "EixoDinamico.h"
using namespace std;
#include<iostream>
#include "Eixo.h"


EixoDinamico::EixoDinamico(double minimoPadrao, double maximoPadrao, Serie* base, bool orientacaoHorizontal) : Eixo("titulo", minimo, maximo){
        this->base = base;
        this->minimoPadrao = minimoPadrao;
        this->maximoPadrao = maximoPadrao;

    if (!base->estaVazia()){

        if (orientacaoHorizontal){
            this->titulo = base->getNomeDoCanalX();
            if (base->getQuantidade() >= 2){
                this->maximo = base->getLimiteSuperior()->getX();
                this->minimo = base->getLimiteInferior()->getX();
            }
            else{
                this->maximo = maximoPadrao;
                this->minimo = minimoPadrao;
            }
        }
        else{
            this->titulo = base->getNomeDoCanalY();
            if (base->getQuantidade() >= 2){
                this->maximo = base->getLimiteSuperior()->getY();
                this->minimo = base->getLimiteInferior()->getY();
            }
            else{
                this->maximo = maximoPadrao;
                this->minimo = minimoPadrao;
            }
        }
    }
}

EixoDinamico::~EixoDinamico(){}
