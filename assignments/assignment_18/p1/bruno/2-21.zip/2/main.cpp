#include <iostream>

#include "Serie.h"
#include "Ponto.h"
#include "InterfaceSerial.h"
#include "Eixo.h"
#include "Grafico.h"
#include "SerieTemporal.h"
#include "EixoDinamico.h"

#define COMM "\\\\.\\COM3"
#include<string>

#define NUMERO_MAXIMO_VALORES 10

using namespace std;

int main() {
  InterfaceSerial* is = new InterfaceSerial();
  is->inicializar(COMM);

  string nome;
  string* canais = is->getNomeDosCanais();
  string canalX,
         canalY,
         titulo;

  int numeroDeCanais,
      numeroDoCanalX,
      numeroDoCanalY;
  double minimo,
         maximo,
         minimoPadrao,
         maximoPadrao;
  char tipo;
  bool horizontal;

  cout << "Aperte o botao reset da placa" << endl;
  cout << "Informe o nome da serie: " ;
  cin >> nome;
  cout << "Escolha o canal X: " << endl;
  for (numeroDeCanais = 1; numeroDeCanais <= is->getQuantidadeDeCanais(); numeroDeCanais++){
    cout << numeroDeCanais << ") " << canais[numeroDeCanais - 1] << endl;
  }
  cin >> numeroDoCanalX;
  canalX  = canais[numeroDoCanalX - 1];

  cout << "Escolha o canal Y: " << endl;
  for (numeroDeCanais = 1; numeroDeCanais <= is->getQuantidadeDeCanais(); numeroDeCanais++){
    cout << numeroDeCanais << ") " << canais[numeroDeCanais-1] << endl;
  }
  cin >> numeroDoCanalY;
  canalY = canais[numeroDoCanalY - 1];


  // Obtem o numero de Pontos a adicionar
  int quantidade;
  cout << "Obter quantos pontos? ";
  cin >> quantidade;
  cout << endl;

  // Cria a Serie
  SerieTemporal *s = new SerieTemporal (nome, canalY);

  cout << "Obtendo os pontos" << endl;
  for (int i = 0; i < quantidade; i++){
    is->atualizar();
    s->adicionar(is->getValor(canalY));
  }
  s->imprimir();
  s->getLimiteInferior()->imprimir();
  s->getLimiteSuperior()->imprimir();
  cout << "Gerando grafico" << endl;
  cout << "O eixo X e estatico ou dinamico (e/d): " << endl;
  cin >> tipo;
  if (tipo == 'e' || tipo == 'E'){
    horizontal = true;
    cout << "Informe o titulo: ";
    cin >> titulo;
    cout << endl;
    cout << "valor minimo: ";
    cin >> minimo;
    cout << endl;
    cout << "valor maximo: ";
    cin >> maximo;
    cout << endl;
    Eixo* eixoX = new Eixo(titulo, minimo, maximo);
    cout << "O eixo Y e estatico ou dinamico (e/d): " << endl;
    cin >> tipo;
    if (tipo == 'e' || tipo == 'E'){
        horizontal = false;
        cout << "Informe o titulo: ";
        cin >> titulo;
        cout << endl;
        cout << "valor minimo: ";
        cin >> minimo;
        cout << endl;
        cout << "valor maximo: ";
        cin >> maximo;
        cout << endl;
        Eixo* eixoY = new Eixo(titulo, minimo, maximo);
        Grafico* g = new Grafico(eixoX, eixoY, s);
        g->desenhar();
        g->~Grafico();
    }
    else if (tipo == 'd' || tipo == 'D'){
        horizontal = false;
        cout << "Vamor minimo padrao: ";
        cin >> minimoPadrao;
        cout << endl;
        cout << "Valor maximo padrao: ";
        cin >> maximoPadrao;
        cout << endl;
        Eixo* eixoDinamicoY = new EixoDinamico(minimoPadrao, maximoPadrao, s, horizontal);
        Grafico* g = new Grafico(eixoX, eixoDinamicoY, s);
        g->desenhar();
        g->~Grafico();
    }

  }
  else if (tipo == 'd' || tipo == 'D'){
    horizontal = true;
    cout << "Vamor minimo padrao: ";
    cin >> minimoPadrao;
    cout << endl;
    cout << "Valor maximo padrao: ";
    cin >> maximoPadrao;
    cout << endl;
    Eixo* eixoDinamicoX = new EixoDinamico(minimoPadrao, maximoPadrao, s, horizontal);
    cout << "O eixo Y e estatico ou dinamico (e/d): " << endl;
    cin >> tipo;
    if (tipo == 'e' || tipo == 'E'){
        horizontal = false;
        cout << "Informe o titulo";
        cin >> titulo;
        cout << endl;
        cout << "valor minimo: ";
        cin >> minimo;
        cout << endl;
        cout << "valor maximo: ";
        cin >> maximo;
        cout << endl;
        Eixo* eixoY = new Eixo(titulo, minimo, maximo);
        Grafico* g = new Grafico(eixoDinamicoX, eixoY, s);
        g->desenhar();
        g->~Grafico();
    }
    else if (tipo == 'd' || tipo == 'D'){
        horizontal = false;
        cout << "Vamor minimo padrao: ";
        cin >> minimoPadrao;
        cout << endl;
        cout << "Valor maximo padrao: ";
        cin >> maximoPadrao;
        cout << endl;
        Eixo* eixoDinamicoY = new EixoDinamico(minimoPadrao, maximoPadrao, s, horizontal);
        Grafico* g = new Grafico(eixoDinamicoX, eixoDinamicoY, s);
        g->desenhar();
        g->~Grafico();
    }
  }

  s->~Serie();


  return 0;
}

