#include "Serie.h"
#include "Ponto.h"
#include<iostream>
using namespace std;

Serie::Serie(string nome, string nomeDoCanalX, string nomeDoCanalY){
    this->nome = nome;
    this->nomeDoCanalX = nomeDoCanalX;
    this->nomeDoCanalY = nomeDoCanalY;
}

Serie::~Serie(){
}

string Serie::getNome(){
    return nome;
}

string Serie::getNomeDoCanalX(){
    return nomeDoCanalX;
}

string Serie::getNomeDoCanalY(){
    return nomeDoCanalY;
}

int Serie::getQuantidade(){
    return quantidade;
}

bool Serie::estaVazia(){

    if (quantidade == 0)
        vazia = true;
    else
        vazia = false;

    return vazia;
}

void Serie::adicionar(double x, double y){

    pontos[quantidade] = new Ponto(x, y);

    quantidade += 1;

}

Ponto* Serie::getPosicao(int posicao){

    if (posicao < NUMERO_MAXIMO_VALORES)
        return pontos[posicao - 1];
    else
        return NULL;
}

Ponto* Serie::getLimiteSuperior(){
    int i;
    double xMaximo, yMaximo;
    xMaximo = pontos[0]->getX();
    yMaximo = pontos[0]->getY();


    if(vazia == false){
        for (i = 1; i < quantidade; i++){
            if (pontos[i]->getX() > xMaximo)
               xMaximo = pontos[i]->getX();
            if (pontos[i]->getY() > yMaximo)
                yMaximo = pontos[i]->getY();
        }

        Ponto *psup = new Ponto(xMaximo, yMaximo);

        return psup;

    }
    return NULL;
}

Ponto* Serie::getLimiteInferior(){
    int i;
    double xMinimo, yMinimo;
    xMinimo = pontos[0]->getX();
    yMinimo = pontos[0]->getY();

    if(vazia == false){
        for (i = 1; i < quantidade; i++){
            if (pontos[i]->getX() < xMinimo)
               xMinimo = pontos[i]->getX();
            if (pontos[i]->getY() < yMinimo)
                yMinimo = pontos[i]->getY();
        }

        Ponto *pinf = new Ponto(xMinimo, yMinimo);

        return pinf;
    }
    return NULL;
}

void Serie::imprimir(){
    int i;
    cout << "Serie " << nome << endl;
    for (i = 0; i < quantidade; i++)
        pontos[i]->imprimir();
}

