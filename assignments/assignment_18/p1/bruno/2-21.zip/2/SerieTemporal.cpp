#include "SerieTemporal.h"
#include "Serie.h"
using namespace std;
#include <iostream>

#define NUMERO_MAXIMO_VALORES 10
SerieTemporal::SerieTemporal(string nome, string nomeDoCanalY) : Serie(nome, "tempo", nomeDoCanalY){}

SerieTemporal::~SerieTemporal(){
}

void SerieTemporal::adicionar(double valor){
    if(tempo >= 1 && quantidade < NUMERO_MAXIMO_VALORES){
            pontos[quantidade] = new Ponto (tempo, valor);
            tempo = tempo + 1;
            quantidade = quantidade + 1;
    }
}

void SerieTemporal::adicionar(double x, double y){
    if (x >= 1 && quantidade < NUMERO_MAXIMO_VALORES){
        for (int i = 0; i < quantidade; i++){
            if ((pontos[i]->getX() - x < 1e-5) && (pontos[i]->getX() - x > -1e-5)){
                pontos[i] = new Ponto (x, y);
                tempo = x;
                return;
            }
        }
        pontos[quantidade] = new Ponto (x, y);
        tempo = x;
        quantidade += 1;
    }
}
