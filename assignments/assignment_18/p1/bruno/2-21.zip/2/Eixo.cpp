#include "Eixo.h"
#include <string>
using namespace std;
#include<iostream>

Eixo::Eixo(string titulo, double minimo, double maximo){
    this->titulo = titulo;
    this->minimo = minimo;
    this->maximo = maximo;
}

Eixo::~Eixo(){
}

string Eixo::getTitulo(){
    return titulo;
}

double Eixo::getMaximo(){
    return maximo;
}

double Eixo::getMinimo(){
    return minimo;
}
