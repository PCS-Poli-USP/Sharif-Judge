#ifndef TELA_H
#define TELA_H

#include <string>
#include <map>
#include <vector>

using namespace std;


class Tela {
public:
  static const int LARGURA_PADRAO;
  static const int ALTURA_PADRAO;

  Tela();
  virtual ~Tela();
  virtual void setEixoX(string nome, double minimo, double maximo);
  virtual void setEixoY(string nome, double minimo, double maximo);
  virtual void plotar(string nomeDaSerie, double x, double y);
  virtual void mostrar(int largura, int altura);
  virtual void mostrar();
private:
  map<string, vector<pair<double, double> > > series;
  double minimoX, minimoY, maximoX, maximoY;
  string nomeX, nomeY;
};

#endif // TELA_H
