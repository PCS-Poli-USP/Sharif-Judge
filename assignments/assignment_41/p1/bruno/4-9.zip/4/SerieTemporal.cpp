#include "SerieTemporal.h"

SerieTemporal::SerieTemporal(string nome, string nomeDoCanalY) : Serie(nome, "Tempo", nomeDoCanalY)
{
}

SerieTemporal::~SerieTemporal()
{
}

void SerieTemporal::adicionar(double valor)
{
	// Se encontrar um indice cujo |Tempo - VarAuxiliar| <= Epsilon, colocar valor nesse indice
	int Indice = encontraPontoComTempoIgual(Tempo_Adicionar_DeUmParam);
	if (Indice != -1)
	{
		//TODO: Qual deve ser o X usado nesse caso? Esperando resposta do forum: https://edisciplinas.usp.br/mod/forum/discuss.php?d=388273#p618998
			//myPoints[Indice] = new Ponto(myPoints[Indice]->getX(), valor);
		myPoints[Indice] = new Ponto(Tempo_Adicionar_DeUmParam, valor);
		return;
	}

	// Codigo abaixo so sera executado se Indice == -1, ou seja, nao achou valor de tempo proximo
	// Nesse caso, basta adicionar um ponto normalmente pelo metodo da classe Pai (Serie::adicionar)
	// no tempo da Var Auxiliar e Y = valor, por fim, incrementar a Var Auxiliar
	Serie::adicionar(Tempo_Adicionar_DeUmParam, valor);
	Tempo_Adicionar_DeUmParam += 1.0;
	return;
}

void SerieTemporal::adicionar(double x, double y)
{
	if (x < 1.0) { return; } // Nao adicionar se tempo < 1

	// Se encontrar um indice cujo |Tempo - x| <= Epsilon, colocar y nesse indice
	int Indice = encontraPontoComTempoIgual(x);
	if (Indice != -1)
	{
		//TODO: Qual deve ser o X usado nesse caso? Esperando resposta do forum: https://edisciplinas.usp.br/mod/forum/discuss.php?d=388273#p618998
			//myPoints[Indice] = new Ponto(myPoints[Indice]->getX(), y);
		myPoints[Indice] = new Ponto(x, y);
		return;
	}

	// Codigo abaixo so sera executado se Indice == -1, ou seja, nao achou valor de tempo proximo
	// Nesse caso, basta adicionar um ponto normalmente pelo metodo da classe Pai (Serie::adicionar)
	Serie::adicionar(x, y);
}

int SerieTemporal::encontraPontoComTempoIgual(double Tempo)
{
	double DistT = 0;

	// Retorna o indice do ponto presente na serie que satisfaz Tempo <= Epsilon
	for (int i = 0; i < getQuantidade(); i++)
	{
		DistT = std::abs(Tempo - myPoints[i]->getX());
		if (DistT <= Epsilon) return i; 
	}

	// Se nao encontrou nenhum ponto na serie que satisfaca, retorna -1.
	return -1;
}
