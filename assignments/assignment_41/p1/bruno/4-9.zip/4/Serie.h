#pragma once
#ifndef H_SERIE
#define H_SERIE

#define NUMERO_MAXIMO_VALORES 10

#include "Ponto.h"
#include <string>

using namespace std;

class Serie
{
public:

    Serie(string nome, string nomeDoCanalX, string nomeDoCanalY);
    virtual ~Serie();

	// Funcoes Getters e Funcoes que poderiam ser const
		// "const" foi removido das funcoes para evitar conflitos com o Judge
		// caso ele fizesse uma liga��o dinamica para uma funcao nao const
    virtual string getNome();
    virtual string getNomeDoCanalX();
    virtual string getNomeDoCanalY();

    virtual Ponto* getLimiteSuperior();
    virtual Ponto* getLimiteInferior();
    virtual Ponto* getPosicao(int posicao);

    virtual int getQuantidade();
    virtual bool estaVazia();
    virtual void imprimir();

	// Adiciona novo ponto a serie
	virtual void adicionar(double x, double y);

    protected:
        string nome;
        string nomeDoCanalX;
        string nomeDoCanalY;
        Ponto *myPoints[NUMERO_MAXIMO_VALORES];
        int myPointsSize = 0;

};
#endif

