#include "Serie.h"

using namespace std;

Serie::Serie(string nome, string nomeDoCanalX, string nomeDoCanalY){
    this->nome = nome;
    this->nomeDoCanalX = nomeDoCanalX;
    this->nomeDoCanalY = nomeDoCanalY;
}

Serie::~Serie(){
	// cout << "Serie destruida" << endl;
}

string Serie::getNome() {
	return nome;
}

string Serie::getNomeDoCanalX() {
	return nomeDoCanalX;
}

string Serie::getNomeDoCanalY() {
	return nomeDoCanalY;
}

int Serie::getQuantidade() {
	return myPointsSize;
}

bool Serie::estaVazia() {
	return (myPointsSize==0);
}

void Serie::adicionar(double x, double y){
	// Nao deixa por mais pontos do que "numero maximo de valores"
	if (this->getQuantidade() >= NUMERO_MAXIMO_VALORES) { return; }

	// Se o vetor myPoints nao tiver cheio, adicionar ponto...
		myPoints[myPointsSize] = new Ponto(x, y);

		myPointsSize++;
		return;
}

/**
* Obt�m um ponto representando o limite superior da Serie.
* A coordenada x desse ponto deve ser o m�ximo valor horizontal
* existente na Serie e a coordenada y deve ser o m�ximo valor
* vertical existente na Serie.
*
* Caso a Serie n�o tenha valores, deve-se retornar nullptr.
*/
Ponto * Serie::getLimiteSuperior() {
	if (this->estaVazia()) { return nullptr; }

	double XMax = myPoints[0]->getX(); // inicializando com primeiros valores
	double YMax = myPoints[0]->getY();

	// Iterar pelos pontos em busca do maximo X e Y
	for (int i = 0; i < this->getQuantidade(); i++) {
		if (myPoints[i]->getX() > XMax) { XMax = myPoints[i]->getX(); }
		if (myPoints[i]->getY() > YMax) { YMax = myPoints[i]->getY(); }
	}

	return new Ponto(XMax, YMax);
}

/**
* Obt�m um ponto representando o limite inferior da Serie.
* A coordenada x desse ponto deve ser o m�nimo valor horizontal
* existente na Serie e a coordenada y deve ser o m�nimo valor
* vertical existente na Serie.
*
* Caso a serie nao tenha valores, deve-se retornar nullptr.
*/
Ponto * Serie::getLimiteInferior()
{
	if (this->estaVazia()) { return nullptr; }

	

	double XMin = myPoints[0]->getX(); // inicializando com primeiros valores
	double YMin = myPoints[0]->getY();

	// Iterar pelos pontos em busca do minimo X e Y
	for (int i = 0; i < this->getQuantidade(); i++){
		if (myPoints[i]->getX() < XMin) XMin = myPoints[i]->getX();
		if (myPoints[i]->getY() < YMin) YMin = myPoints[i]->getY();
	}

	return new Ponto(XMin, YMin);
}

// Retorna o ponto na "posicao" da serie, nullptr se nao existir
Ponto * Serie::getPosicao(int posicao)
{
	// posicao >= getQtd j� cobre a possibilidade de estar vazio 0 >= 0
	if ((posicao >= this->getQuantidade()) || (posicao < 0)) { return nullptr; }

	return new Ponto(myPoints[posicao]->getX(), myPoints[posicao]->getY());
}

void Serie::imprimir()
{
	std::cout << "Serie " << this->getNome() << std::endl;
	for (int i = 0; i < this->getQuantidade(); i++){
		myPoints[i]->imprimir();
	}
	std::cout << std::endl;
	return;
}
