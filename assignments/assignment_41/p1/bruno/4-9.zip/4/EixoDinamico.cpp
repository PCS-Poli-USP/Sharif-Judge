#include "EixoDinamico.h"

using namespace std;

EixoDinamico::EixoDinamico(double minimoPadrao, double maximoPadrao, Serie* base, bool orientacaoHorizontal)
			: Eixo("Default EixoDinamico", minimoPadrao, maximoPadrao)
{
	
	// Configurar titulo, minimo e maximo do pai "eixo"
	if (orientacaoHorizontal) {
		titulo = base->getNomeDoCanalX();
		minimo = base->getLimiteInferior()->getX();
		maximo = base->getLimiteSuperior()->getX();
	}
	else {
		titulo = base->getNomeDoCanalY();
		minimo = base->getLimiteInferior()->getY();
		maximo = base->getLimiteSuperior()->getY();
	}

	// Validar as configuracoes acima conforme o enunciado
		// Se serie tiver menos de 2 pontos ou min e max forem proximos usar o padrao
	if ((base->getQuantidade() < 2) || (std::abs(maximo - minimo) <= Epsilon)) {
		minimo = minimoPadrao;
		maximo = maximoPadrao;
	}
}

EixoDinamico::~EixoDinamico(){
    // cout << "EixoDinamico destruido" << endl;
}
