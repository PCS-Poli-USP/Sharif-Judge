#pragma once
#ifndef H_PONTO
#define H_PONTO

#include <cmath>
#include <iostream>

class Ponto
{
public:

        Ponto(double x, double y);
        virtual ~Ponto();

		double getX() const;
		double getY() const;

		void imprimir() const;

		// Retorna 1 quando esse ponto e "outro" forem iguais. outro eh const pois a funcao nao mexe nele.
		bool eIgual(const Ponto* outro) const;

protected:
        // Coordenadas x e y, respectivamente.
        double Coordenada[2] = {0.0, 0.0};

		// Usado no metodo eIgual
		const double Epsilon = 1E-5;
};

#endif // !H_PONTO
