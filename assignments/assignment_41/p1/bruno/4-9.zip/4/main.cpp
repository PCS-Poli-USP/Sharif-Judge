#include "main.h"

void main() {
	using std::cout; using std::endl;

	/**
	// Se algum dos testes da classe de Teste falhar, sera lancada uma exception e return false;
	Teste *Testador = new Teste();
	if (Testador->Testar_Todas_as_Classes()) { cout << "Sucesso"; }
	else { cout << "Erro"; }
	/**/

	// Inicializar o Interface Serial
		// Ele vai printar "Aperte o botao reset da placa"
		InterfaceSerial *is = new InterfaceSerial("COM1");

	// Inicializar a Serie
		Serie *S = nullptr;
		SerieTemporal *ST = nullptr;
		std::string Serie_Nome = getInput("Informe o nome da serie: ");
		std::string Serie_CanalX = getCanal("Escolha o canal X:", *is, true);
		std::string Serie_CanalY = getCanal("Escolha o canal Y:", *is);

		Serie_CanalX == "Tempo" ? ST = new SerieTemporal(Serie_Nome, Serie_CanalY)
								: S = new Serie(Serie_Nome, Serie_CanalX, Serie_CanalY);

	// Quantos pontos devemos obter? Obter pontos
		if (S != 0 && S != nullptr) { amostrarPontos(getNumeroPontos(*is, S), *is, S); }
		else if (ST != 0 && ST != nullptr) { amostrarPontos(getNumeroPontos(*is, S), *is, ST); }
		else { cout << "Nenhum objeto serie inicializado\n"; }

		cout << "Gerando o grafico\n";
	
	// Construir os Eixos
		Eixo *Eixo_X = nullptr;
		Eixo *Eixo_Y = nullptr;
		if (S != 0 && S != nullptr) { Eixo_X = construirEixo("X", S); Eixo_Y = construirEixo("Y", S); }
		else if (ST != 0 && ST != nullptr) { Eixo_X = construirEixo("X", ST); Eixo_Y = construirEixo("Y", ST); }
		else { cout << "Nenhum objeto serie inicializado\n"; }
	
	// Criar grafico
		Grafico *Graf = nullptr;
		if (S != 0 && S != nullptr) { Graf = new Grafico(Eixo_X, Eixo_Y, S); }
		else if (ST != 0 && ST != nullptr) { Graf = new Grafico(Eixo_X, Eixo_Y, ST); }
		else { cout << "Nenhum objeto serie inicializado\n"; }
	
	// Mostrar grafico
		Graf->desenhar();
	return;
}

void Imprimir_Limites(Serie &S)
{
	using std::cout;
	Ponto *P = nullptr;

	P = S.getLimiteSuperior();
	cout << "Limite Superior: ";
	if (P == nullptr) { cout << "nullptr\n"; } else { P->imprimir(); }

	P = S.getLimiteInferior();
	cout << "Limite Inferior: ";
	if (P == nullptr) { cout << "nullptr\n"; } else { P->imprimir(); }

	return;
}

std::string getInput(std::string Mensagem)
{
	using std::cout; using std::cin; using std::endl;

	std::string Input;
	
	cout << Mensagem;
	cin >> Input;
	//cout << endl;
	return Input;
}

std::string getCanal(std::string Mensagem, InterfaceSerial &is, bool MostrarCanalTempo)
{
	using std::cout; using std::cin; using std::endl;

	std::string CanalEscolhido = "";
	bool InputValido = 0;
	
	while (!InputValido)
	{
	// Imprimir mensagem pedindo o canal
		cout << Mensagem << endl;
	// Fazer a impressao dos canais disponiveis
		// Canal Tempo
		if (MostrarCanalTempo) { cout << "0) Tempo" << endl;	}
		// Canais do Interface Serial
		for (int i = 0; i < is.getQuantidadeDeCanais(); i++)
		{
			cout << (i + 1) << ") " << is.getNomeDosCanais()[i] << endl;
		}
	// Pegar input do user
		cin >> CanalEscolhido;
	// Validar input do user
		try
		{
			if ((stoi(CanalEscolhido) > 0 && stoi(CanalEscolhido) <= is.getQuantidadeDeCanais()) || (stoi(CanalEscolhido)==0 && MostrarCanalTempo))
			{
				InputValido = 1;
				if (stoi(CanalEscolhido) == 0) {
					CanalEscolhido = "Tempo";
				}
				else {
					CanalEscolhido = is.getNomeDosCanais()[stoi(CanalEscolhido) - 1]; // -1 pq o indice do user comeca em 1 e nao em zero.
				}
			}
			else
			{
				cout << "Canal Invalido. Digite um numero de " << (MostrarCanalTempo ? 0 : 1) << " a " << is.getQuantidadeDeCanais() << endl;
			}
		}
		catch (const std::exception& e)
		{
			cout << "EXCEPTION: " << e.what() << endl;
			cout << "Digite um numero de " << (MostrarCanalTempo ? 0 : 1) << " a " << is.getQuantidadeDeCanais() << endl;
		}
		//cout << endl;
	}

	return CanalEscolhido;
}

int getNumeroPontos(InterfaceSerial & is, Serie *S)
{
	using std::cout; using std::cin; using std::endl;

	std::string QtdPontos = "";
	bool InputValido = 0;

	// Pedir numero de pontos ate vir input valido
	while (!InputValido)
	{
		// Imprimir mensagem pedindo o canal
		cout << "Obter quantos pontos? ";

		// Pegar input do user e validar
		cin >> QtdPontos;
		try
		{
			if (stoi(QtdPontos) >= 0) { InputValido = 1; }
		}
		catch (const std::exception& e)
		{
			cout << "EXCEPTION: " << e.what() << endl;
			cout << "Digite um numero." << endl;
		}
		//cout << endl;
	}

	cout << "Obtendo os pontos...\n";

	return stoi(QtdPontos);
}

void amostrarPontos(int QtdPontos, InterfaceSerial & is, Serie * S)
{
	for (int i = 0; i < QtdPontos; i++)
	{
		if (!is.atualizar()) { std::cout << "Atualizar falhou no ponto " << i << endl; }
		S->adicionar(is.getValor(S->getNomeDoCanalX()), is.getValor(S->getNomeDoCanalY()));
	}

	//std::cout << endl;
}

void amostrarPontos(int QtdPontos, InterfaceSerial & is, SerieTemporal * ST)
{
	for (int i = 0; i < QtdPontos; i++)
	{
		if (!is.atualizar()) { std::cout << "Atualizar falhou no ponto " << i << endl; }
		ST->adicionar(is.getValor(ST->getNomeDoCanalY()));
	}

	//std::cout << endl;
}

Eixo* construirEixo(std::string Nome_do_Eixo, Serie *serieBase_EixoDinamico)
{
	using std::string;

	string Eixo_Tipo;
	string Tem_Padrao = "";
	double Eixo_valMinimo = 0.0;
	double Eixo_valMaximo = 0.0;

	// Perguntar se eh estatico ou dinamico
	bool Input_Valido = false;
	while (!Input_Valido) {
		Eixo_Tipo = getInput("O eixo " + Nome_do_Eixo + " e estatico ou dinamico (e/d): ");
		if (Eixo_Tipo == "e" || Eixo_Tipo == "d") { Input_Valido = true; }
	}
	
	// Se for dinamico, perguntar se eh horizontal
	// NO ENUNCIADO ELE NAO PEDE PARA PERGUNTAR ISSO, ENTAO FOI TIRADO FORA
	/// if (Eixo_Tipo == "d") {
	/// 	bool Input_Valido = false;
	/// 	while (!Input_Valido) {
	/// 		Eixo_Tipo = getInput("O eixo dinamico deve ser horizontal (s/n): ");
	/// 		if (Eixo_Tipo == "s" || Eixo_Tipo == "n") { Input_Valido = true; }
	/// 	}
	/// }

	if (Eixo_Tipo == "e") { Nome_do_Eixo = getInput("Informe o titulo: "); }
	else { Tem_Padrao = " padrao"; }

	Input_Valido = false;
	while (!Input_Valido) {
		try { Eixo_valMinimo = stod(getInput("Valor minimo" + Tem_Padrao + ": ")); Input_Valido = true; }
		catch (const std::exception& e)	{ cout << "EXCEPTION: " << e.what() << endl; }
	}

	Input_Valido = false;
	while (!Input_Valido) {
		try { Eixo_valMaximo = stod(getInput("Valor maximo" + Tem_Padrao + ": ")); Input_Valido = true; }
		catch (const std::exception& e) { cout << "EXCEPTION: " << e.what() << endl; }
	}

	if (Eixo_Tipo == "e") { return new Eixo(Nome_do_Eixo, Eixo_valMinimo, Eixo_valMaximo); }
	// Eixo Dinamico Horizontal
	// No enunciado ele nao pede para perguntar se eh horizontal ou nao, entao assume-se que eh horizontal...
	if (Eixo_Tipo == "s" || Eixo_Tipo == "d") { return new EixoDinamico(Eixo_valMinimo, Eixo_valMaximo,serieBase_EixoDinamico, true); }
	// Eixo Dinamico Nao Horizontal
	if (Eixo_Tipo == "n") { return new EixoDinamico(Eixo_valMinimo, Eixo_valMaximo, serieBase_EixoDinamico, false); }

	// Chegou aqui e nao retornou nada? deu pau!
	return nullptr;
}