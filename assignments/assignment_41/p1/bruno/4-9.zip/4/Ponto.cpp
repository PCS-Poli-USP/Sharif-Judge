#include "Ponto.h"

using namespace std;

Ponto::Ponto(double x, double y){
    Coordenada[0] = x;
    Coordenada[1] = y;
}

Ponto::~Ponto(){
	// cout << "Ponto destruido" << endl;
}

double Ponto::getX() const
{
	return Coordenada[0];
}

double Ponto::getY() const
{
	return Coordenada[1];
}


void Ponto::imprimir() const {
	std::cout << "(" << Coordenada[0] << ", " << Coordenada[1] << ")" << std::endl;
	return;
}

bool Ponto::eIgual(const Ponto * outro) const
{
	double DistX = std::abs(outro->getX() - Coordenada[0]);
	double DistY = std::abs(outro->getY() - Coordenada[1]);

	if (DistX <= Epsilon && DistY <= Epsilon) return true;

	return false;
}
