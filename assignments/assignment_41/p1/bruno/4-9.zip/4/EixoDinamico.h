#ifndef EIXODINAMICO_H
#define EIXODINAMICO_H

#include "Eixo.h"
#include "Serie.h"
#include <iostream>
#include <cmath> // para ter std::abs


using namespace std;

class EixoDinamico : public Eixo {
    public:
        EixoDinamico(double minimoPadrao, double maximoPadrao, Serie* base, bool orientacaoHorizontal);
        virtual ~EixoDinamico();

    protected:
		// Nao eh necessario redefinir titulo, minimo, maximo pois ja existem no pai
		const double Epsilon = 1E-5;
};

#endif // EIXODINAMICO_H
