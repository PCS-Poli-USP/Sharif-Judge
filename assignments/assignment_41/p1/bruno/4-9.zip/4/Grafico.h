#ifndef GRAFICO_H
#define GRAFICO_H

#include "Eixo.h"
#include "Serie.h"
#include "Tela.h"
#include <string>
#include <iostream>

class Grafico
{
    public:
        Grafico(Eixo* x, Eixo* y, Serie* serie);
        virtual ~Grafico();

        Eixo* getEixoX();
        Eixo* getEixoY();
        Serie* getSerie();

        void desenhar();

    protected:
		Eixo *myX, *myY;
		Serie *mySerie;
};

#endif // GRAFICO_H
