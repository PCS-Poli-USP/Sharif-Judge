#include "Grafico.h"

using namespace std;

Grafico::Grafico(Eixo* x, Eixo* y, Serie* serie){
	myX = x;
	myY = y;
	mySerie = serie;

	if (x == nullptr || y == nullptr || serie == nullptr)
	{
		std::cout << "Classe grafico inicializada com Eixo X, Eixo Y ou Serie == nullptr ):\n";
	}
}

Grafico::~Grafico(){
	// cout << "Grafico destruido" << endl;
}

Eixo * Grafico::getEixoX()
{
	return myX;
}

Eixo * Grafico::getEixoY()
{
	return myY;
}

Serie * Grafico::getSerie()
{
	return mySerie;
}

void Grafico::desenhar(){

    Tela* t = new Tela;
	// Configurar eixos
    t->setEixoX(myX->getTitulo(), myX->getMinimo(), myX->getMaximo());
    t->setEixoY(myY->getTitulo(), myY->getMinimo(), myY->getMaximo());

	// for each ponto in mySerie, adicionar ao plotar da tela
	for (int ponto = 0; ponto < mySerie->getQuantidade(); ponto++) {
		t->plotar(mySerie->getNome(),
				  mySerie->getPosicao(ponto)->getX(),
			      mySerie->getPosicao(ponto)->getY());
	}

	// Mostrar a tela
    t->mostrar();

    delete t;

}



