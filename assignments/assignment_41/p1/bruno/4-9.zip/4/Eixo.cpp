#include "Eixo.h"

using namespace std;

Eixo::Eixo(string titulo, double minimo, double maximo){
    this->titulo = titulo;
    this->minimo = minimo;
    this->maximo = maximo;
}

Eixo::~Eixo(){
    // cout << "Eixo destruido" << endl;
}

string Eixo::getTitulo(){
    return titulo;
}

double Eixo::getMinimo(){
    return minimo;
}

double Eixo::getMaximo(){
    return maximo;
}
