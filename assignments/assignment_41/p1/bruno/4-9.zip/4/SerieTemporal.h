#pragma once
#ifndef H_SERIETEMPORAL
#define H_SERIETEMPORAL

#include "Serie.h"
#include <cmath> // para usar std::abs

class SerieTemporal : public Serie
{
public:
	// Cria uma nova serie. O nome do canal X deve ser "Tempo"
	SerieTemporal(string nome, string nomeDoCanalY);
	virtual ~SerieTemporal();

	/**
	Adiciona um novo Ponto a Serie, no instante seguinte ao do
	ponto anterior adicionado por este m�todo. O primeiro ponto
	deve ser adicionado no instante 1.
	*/
	virtual void adicionar(double valor);

	/**
	* Adiciona um Ponto a Serie informando a coordenada x e y.
	* Caso j� exista um ponto cuja coordenada x seja suficientemente
	* pr�xima ao do valor x informado, ao inv�s de adicionar o ponto,
	* altere o valor anterior (mantendo sua posi��o no arranjo)
	* ao considerar a nova coordenada y.
	* Caso a coordenada x do ponto for < 1, o ponto n�o deve ser adicionado.
	*/
	virtual void adicionar(double x, double y);

protected:
	// Retorna o indice do ponto com tempo proximo ao Tempo passado no parametro
	// retorna -1 se nao houver ponto proximo (Proximo eh <= Epsilon)
	// (esse metodo nao pode ser const pois getQuantidade() nao eh const)
	int encontraPontoComTempoIgual(double Tempo);
	const double Epsilon = 1E-5;

	// Variavel auxiliar para o metodo adicionar(valor)
	double Tempo_Adicionar_DeUmParam = 1.0;
};

#endif //H_SERIETEMPORAL
