#pragma once
#ifndef H_MAIN
#define H_MAIN

#include <iostream>
#include <cmath> // para usar pow na funcao Teste_Serie() 100 elementos
#include <string>

// Include das nossas classes
#include "Eixo.h"
#include "EixoDinamico.h"
#include "Grafico.h"
#include "InterfaceSerial.h"
#include "Ponto.h"
#include "Serie.h"
#include "SerieTemporal.h"
#include "Tela.h"
// #include "Teste.h" // Nossa classe de testes das outras classes


void main();

// Funcoes Utilizadas no main
void Imprimir_Limites(Serie &S);
std::string getInput(std::string Mensagem);
std::string getCanal(std::string Mensagem, InterfaceSerial &is, bool MostrarCanalTempo = false);
int getNumeroPontos(InterfaceSerial & is, Serie *S);

void amostrarPontos(int QtdPontos, InterfaceSerial & is, Serie * S);
void amostrarPontos(int QtdPontos, InterfaceSerial & is, SerieTemporal * ST);

Eixo* construirEixo(std::string Nome_do_Eixo, Serie *serieBase_EixoDinamico);


#endif